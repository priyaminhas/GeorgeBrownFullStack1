var num1=5;
var trufal=true;
var str='Test String';
console.log(num1);
console.log(trufal);
console.log(str);