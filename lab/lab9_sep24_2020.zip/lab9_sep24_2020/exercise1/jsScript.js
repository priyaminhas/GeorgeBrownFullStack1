console.log("My first JS function");
helloWorld();

function helloWorld()
{
    console.log("Hello World");
}