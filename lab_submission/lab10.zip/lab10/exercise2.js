function calculatePoints(num1,num2,num3){
    var total=0;
    total+=num1*3;
    total+=num2*1;
    total+=num3*0;
    console.log(total);
}
calculatePoints(3,4,2);
calculatePoints(5,0,2);
calculatePoints(0,0,1);