var fixedPi=function (param) {
    var piVal=Math.PI;
   var roundPi=piVal.toFixed(param);
    console.log(roundPi);
  }
  fixedPi(5);
  fixedPi(4);
  fixedPi(15);
  